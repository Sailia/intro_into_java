class Syema1c
{
   public static void main( String[] args )
   {
      int a = 1;
      
      System.out.println("a   a^2   a^3");
      System.out.println( a + "   " + a * a + "     " +  a * a * a );
      System.out.println( ++a + "   " + a * a + "     " +  a * a * a );
      System.out.println( ++a + "   " + + a * a + "     " +  a * a * a );
   }

}