class Syema1b
{
   public static void main(String[] args)
   {
      double length1 = 3.0;
      double length2 = 4.0;
      double length3 = 5.0;
      
      double base = 6.0;
      double height = 17.0;
      
      double perimeter = length1 + length2 + length3;
      double area = base * height / 2;
      
      System.out.println( "The perimeter of the triangle is: " + perimeter );
      System.out.println( "The area of the triangle is: " + area );
   }
}