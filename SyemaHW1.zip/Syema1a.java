class Syema1a 

{
   public static void main(String[] args)
   {
      System.out.println("Syema Ailia \n"); 
      System.out.print("s-ailia@neiu.edu");
   }
   
}